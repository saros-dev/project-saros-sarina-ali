let numbers = [10,15,20,25,30,35,40]
let oddnumbers = []

// function filterOddNumber() {
//     numbers.forEach(() => {
//         if( numbers%2=== 0) {
//             console.log("hello")
//             oddnumbers.push(number);
//         }
        
//     });
    
// }

function filterOddNumber(){
    for (let index = 0; index < numbers.length; index++) {
        if (numbers[index]%2 ===1) {
            
            oddnumbers.push(numbers[index])
        }  
        
    }






}
filterOddNumber()
console.log(oddnumbers);
