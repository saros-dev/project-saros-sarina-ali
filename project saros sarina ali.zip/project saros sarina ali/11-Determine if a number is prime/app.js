let number= 7
function calculator(){

let counter= 0

for (let index = 2; index < number; index++) {
    if (number %index ===0) {
         counter++
    }
    
}
if (counter ===0) {
    return ("prime")
}
else{
    return ("unprime")
}
}

calculator()
console.log(calculator())