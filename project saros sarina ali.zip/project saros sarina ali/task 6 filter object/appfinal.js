const objects= {ipad: 7 , iphone:6 , macbook: 9 } ;
const keysToKeep = ['ipad' , 'macbook']
let filteredObj = filterObjectFunction(objects, keysToKeep)

function  filterObjectFunction(obj, keys) {

    if (typeof obj !== 'object' || !Array.isArray(keys)) {
        throw new Error('Key Not Found')

    }

    let filteredObj = {} ;

    keys.forEach(key =>{
        if (key in obj){
            filteredObj[key] = obj[key];
        }
    });

    return filteredObj;

}

console.log(filteredObj)