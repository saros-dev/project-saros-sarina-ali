function fetchData() {

    fetch('https://fakestoreapi.com/products')
        .then(response => {
        
            if (!response.ok) {
            throw new Error('error');
          }
        
        return response.json();
       
    })
    .then(data => {

        console.log(data);
    })
    .catch(error => {
        console.error("error with fetching data", error);
    });


}

fetchData();