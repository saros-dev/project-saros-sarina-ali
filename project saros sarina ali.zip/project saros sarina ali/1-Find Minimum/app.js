
function min() {
    let numbers = [10,20,15]
    let minimumvalue = Math.min(...numbers)
    
    console.log(minimumvalue)
}
min()