function  mergeArray (arr1,arr2) {
    if (!Array.isArray(arr1) ||  !Array.isArray(arr2)) {
        throw new Error("Both items must be array") ;

    }
    
    let mergeArray = [...arr1, ...arr2]


        
    return mergeArray


}
const array1 = [1,5,8, "ali"]
const array2 = [2, 4,7, "amir"]
let resultArray =  mergeArray(array1, array2)

console.log(resultArray)