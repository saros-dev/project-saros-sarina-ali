
function objectToArray(obj) {  
    return Object.entries(obj);  
}  

const input = { a: 1, b: 2, c:3, d:4 };  
const result = objectToArray(input);  
console.log(result);