let elements= ['a' , 'b' , 'a' , 'c' , 'a' , 'b']
let count={}


function counter() {
    for (index = 0; index < elements.length; index++) {
        let element = elements[index];
        if (count[element]) {
            count[element] += 1;
        } else {
            count[element] = 1;
        }
    
}}
counter()
console.log(count)