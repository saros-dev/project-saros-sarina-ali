function sumNestedValues(obj) {  
    let sum = 0;  

    function recursiveSum(innerObj) {  
        for (let key in innerObj) {  
            if (typeof innerObj[key] === 'object' && innerObj[key] !== null) {  
                recursiveSum(innerObj[key]);  
            } else if (typeof innerObj[key] === 'number') {  
                sum += innerObj[key];  
            }  
        }  
    }  

    recursiveSum(obj);  
    return sum;  
}  

const exampleObj = {a: 1, b: {c: 2, d: {e: 3}}};  
console.log(sumNestedValues(exampleObj));