

function WordCount(str) { 
    return str.split(" ").length;
  }
  
  console.log(WordCount("boot camp frontend"));






  //////////////////////این راه خیلی راحت تری ولی چون گفته از حلقه استفاده کن من این راه رو نرفتم