function countWords(str) {  
    let wordCount = 0;  
    let inWord = false;  

    for (let i = 0; i < str.length; i++) {  
        const char = str[i];  
        
        if (char !== ' ') {  
            if (!inWord) {  
          
                inWord = true;  
                wordCount++;  
            }  
        } else {  
            
            inWord = false;  
        }  
    }  

    return wordCount;  
}  

  
const inputString = "boot camp frontend";  
const result = countWords(inputString);  
console.log(result);