function checkPasswordStrength(password) {
    if (password.length < 6) {
        return 'weak';
    } else if (password.length >= 6 && !/[A-Z]/.test(password)) {
        return 'moderate';
    } else if (password.length >= 8 && /[a-z]/.test(password) && /[A-Z]/.test(password)) {
        return 'strong';
    } else {  
        return 'invalid';  
    }  
}

console.log(checkPasswordStrength("sar"));
console.log(checkPasswordStrength("sarina")); 
console.log(checkPasswordStrength("SariNA"));