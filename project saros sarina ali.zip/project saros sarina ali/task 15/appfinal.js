async function asyncAwait(){
    try{
        const response = await fetch ('https://jsonplaceholder.typicode.com/posts');
        
        if (!response.ok) {
            throw new Error('Response Fail')
        }

        const content = await response.json();

        content.forEach( content=> {
            console.log(`ID:  ${content.id} , Title: ${content.title} `)
            
        });


    } catch (error) {
        console.log("error" , error);
    }
}

asyncAwait();