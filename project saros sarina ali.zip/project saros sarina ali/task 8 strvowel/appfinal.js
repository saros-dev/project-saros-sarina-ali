const str1= "Hi I am Saros "
const str2= "TV"

function containsVowel(str) {

    const vowel = /[aeiouAEIOU]/

    return vowel.test(str);
}

console.log(containsVowel(str1))
console.log(containsVowel(str2))