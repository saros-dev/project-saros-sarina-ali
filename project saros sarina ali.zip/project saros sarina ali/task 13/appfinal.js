async function fetchUserIds(){
        try{
        const  response = await fetch('https://jsonplaceholder.typicode.com/users');

        if (!response.ok){
            throw new Error('error');

        }

     const  users = await response.json();

     users.forEach(users => {
        console.log(users.id);
     });



   
    } catch (error) {
        console.log("error" , error);
    }

}

fetchUserIds();